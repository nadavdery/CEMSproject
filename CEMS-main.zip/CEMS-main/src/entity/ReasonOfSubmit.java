
package entity;

import java.io.Serializable;

/**
 * This class has 2 types of variables for a field value of: reason_of_submit,
 * for examOfStudent entity. 
 * HML diagram: This class does not exist in our charts. 
 * Added in favor of student solve exam documentation.
 * 
 * @author Hadar Iluz
 */
public enum ReasonOfSubmit implements Serializable {
	forced, initiated
}
