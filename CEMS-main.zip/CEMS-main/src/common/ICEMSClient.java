package common;

import logic.ResponseFromServer;

public interface ICEMSClient {
	public ResponseFromServer getResponseFromServer();
}
